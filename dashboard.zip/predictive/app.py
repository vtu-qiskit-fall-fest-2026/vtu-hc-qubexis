import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path
import numpy as np
import joblib
import pennylane as qml

# --------------------------------------------------
# PAGE SETTINGS
# --------------------------------------------------

st.set_page_config(
    page_title="Quantum Predictive Maintenance",
    page_icon="⚛️",
    layout="wide"
)

# --------------------------------------------------
# LOAD COMPARISON RESULTS
# --------------------------------------------------

results_path = (
    Path(__file__).resolve().parent
    / "comparison_results.csv"
)

results = None

if results_path.exists():
    try:
        results = pd.read_csv(results_path)
    except Exception:
        results = None

# --------------------------------------------------
# LOAD SAVED MODELS
# --------------------------------------------------

MODEL_DIR = Path(__file__).resolve().parent / "saved_models"

classical_data = joblib.load(
    MODEL_DIR / "classical_model.joblib"
)

quantum_data = joblib.load(
    MODEL_DIR / "quantum_model.joblib"
)

classical_model = classical_data["model"]

standard_scaler = classical_data["standard_scaler"]
pca = classical_data["pca"]

rf_threshold = classical_data["threshold"]

angle_scaler = quantum_data["angle_scaler"]
q_threshold = quantum_data["threshold"]

weights = quantum_data["weights"]

# --------------------------------------------------
# QUANTUM CIRCUIT FOR PREDICTION
# --------------------------------------------------

n_qubits = quantum_data["n_qubits"]
n_layers = quantum_data["n_layers"]

dev = qml.device("default.qubit", wires=n_qubits)

@qml.qnode(dev, interface="autograd", diff_method="backprop")
def quantum_circuit(weights, x):

    qml.AngleEmbedding(
        features=x,
        wires=range(n_qubits),
        rotation="Y"
    )

    qml.StronglyEntanglingLayers(
        weights,
        wires=range(n_qubits)
    )

    return qml.expval(qml.PauliZ(0))


# --------------------------------------------------
# PREDICTION FUNCTION
# --------------------------------------------------

def predict_machine(sensor_values):

    sensor_values = np.array(
        sensor_values,
        dtype=float
    ).reshape(1, -1)

    # Classical preprocessing
    classical_scaled = standard_scaler.transform(
        sensor_values
    )

    classical_pca = pca.transform(
        classical_scaled
    )

    # Random Forest prediction
    classical_score = classical_model.predict_proba(
        classical_pca
    )[0, 1]

    classical_prediction = int(
        classical_score >= rf_threshold
    )

    # Quantum preprocessing
    quantum_angles = angle_scaler.transform(
        classical_pca
    )

    # Quantum prediction
    quantum_score = float(
        quantum_circuit(
            weights,
            quantum_angles[0]
        )
    )

    quantum_prediction = int(
        quantum_score >= q_threshold
    )

    return {
        "classical_prediction": classical_prediction,
        "classical_score": float(classical_score),
        "quantum_prediction": quantum_prediction,
        "quantum_score": quantum_score
    }
# --------------------------------------------------

n_qubits = quantum_data["n_qubits"]
n_layers = quantum_data["n_layers"]

dev = qml.device("default.qubit", wires=n_qubits)

@qml.qnode(dev, interface="autograd", diff_method="backprop")
def quantum_circuit(weights, x):

    qml.AngleEmbedding(
        features=x,
        wires=range(n_qubits),
        rotation="Y"
    )

    qml.StronglyEntanglingLayers(
        weights,
        wires=range(n_qubits)
    )

    return qml.expval(qml.PauliZ(0))


# --------------------------------------------------
# PREDICTION FUNCTION
# --------------------------------------------------

def predict_machine(sensor_values):

    sensor_values = np.array(
        sensor_values,
        dtype=float
    ).reshape(1, -1)

    # Classical preprocessing
    classical_scaled = standard_scaler.transform(
        sensor_values
    )

    classical_pca = pca.transform(
        classical_scaled
    )

    # Random Forest prediction
    classical_score = classical_model.predict_proba(
        classical_pca
    )[0, 1]

    classical_prediction = int(
        classical_score >= rf_threshold
    )

    # Quantum preprocessing
    quantum_angles = angle_scaler.transform(
        classical_pca
    )

    # Quantum prediction
    quantum_score = float(
        quantum_circuit(
            weights,
            quantum_angles[0]
        )
    )

    quantum_prediction = int(
        quantum_score >= q_threshold
    )

    return {
        "classical_prediction": classical_prediction,
        "classical_score": float(classical_score),
        "quantum_prediction": quantum_prediction,
        "quantum_score": quantum_score
    }
    
# --------------------------------------------------
# DASHBOARD STYLE
# --------------------------------------------------

st.markdown("""
<style>

/* Main dashboard background */

.stApp {
    background-color: #f5f7fb;
    color: #0b1b3a;
}

/* Main content spacing */

.block-container {
    padding-top: 1.5rem;
    padding-bottom: 2rem;
}

/* Sidebar */

[data-testid="stSidebar"] {
    background-color: #061b43;
}

[data-testid="stSidebar"] * {
    color: #ffffff !important;
}

/* Sidebar navigation */

[data-testid="stSidebar"] [data-testid="stRadio"] label {
    background-color: #102b55;
    padding: 8px;
    border-radius: 8px;
}

/* Titles */

h1, h2, h3 {
    color: #0b1b3a;
}

/* Metric cards */

div[data-testid="stMetric"] {
    background-color: #ffffff;
    border: 1px solid #dce3ee;
    border-radius: 12px;
    padding: 18px;
    box-shadow: 0 2px 5px rgba(10, 30, 70, 0.06);
}

/* Buttons */

.stButton > button {
    background-color: #0097a7;
    color: white;
    border-radius: 8px;
    border: none;
    min-height: 42px;
    font-weight: 600;
}

.stButton > button:hover {
    background-color: #007f8e;
    color: white;
}

/* Input widgets */

.stSlider, [data-testid="stSelectbox"] {
    background-color: white;
}

/* Tables */

[data-testid="stDataFrame"] {
    border: 1px solid #dce3ee;
    border-radius: 10px;
}

/* Custom dashboard cards */

.dashboard-card {
    background-color: #ffffff;
    border: 1px solid #dce3ee;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 2px 5px rgba(10, 30, 70, 0.06);
    margin-bottom: 12px;
}

.card-heading {
    font-size: 19px;
    font-weight: 700;
    color: #0b1b3a;
    margin-bottom: 12px;
}

.status-text {
    color: #607086;
    font-size: 14px;
}

</style>
""", unsafe_allow_html=True)

# --------------------------------------------------
# SIDEBAR
# --------------------------------------------------

st.sidebar.markdown(
    """
    <div style="text-align:center; padding:20px 0;">
        <div style="font-size:45px;">⚛️</div>
        <h2 style="color:white; margin:0;">Quantum PM</h2>
        <p style="color:#62e9f2;">AI-Integrated System</p>
    </div>
    """,
    unsafe_allow_html=True
)

page = st.sidebar.radio(
    "Navigation",
    [
        "Overview",
        "Live Prediction",
        "Model Comparison",
        "Dataset",
        "Documentation"
    ]
)

st.sidebar.markdown("---")

st.sidebar.markdown(
    """
    <div style="
        background:#102b55;
        border:1px solid #31517c;
        border-radius:10px;
        padding:15px;
        text-align:center;
    ">
        <h4 style="color:#62e9f2;">Team E&I Innovators</h4>
        <p>Quantum Predictive Maintenance</p>
        <small>AI for a Smarter Tomorrow</small>
    </div>
    """,
    unsafe_allow_html=True
)

st.sidebar.caption("Version 1.0")

# --------------------------------------------------
# OVERVIEW PAGE
# --------------------------------------------------

if page == "Overview":

    st.title("Quantum Predictive Maintenance")

    st.subheader("Predictive Maintenance Dashboard")

    st.markdown(
        "<p style='color:#0097a7;'>"
        "Classical ML vs Quantum ML"
        "</p>",
        unsafe_allow_html=True
    )

    # TOP METRIC CARDS

    c1, c2, c3, c4 = st.columns(4)

    with c1:
        st.metric(
            "Sensor Features",
            "5",
            help="Air temperature, process temperature, "
                 "speed, torque and tool wear"
        )

    with c2:
        st.metric(
            "Classical Model",
            "SVM",
            help="Classical machine learning model"
        )

    with c3:
        st.metric(
            "Quantum Model",
            "VQC",
            help="Variational Quantum Classifier"
        )

    with c4:
        st.metric(
            "Prediction Status",
            "Not Connected",
            help="Model inference needs to be integrated"
        )

    st.markdown("")

    # SENSOR INPUT AND PREDICTION AREA

    left, right = st.columns([1, 1.5])

    # SENSOR INPUTS

    with left:

        st.markdown(
            """
            <div class="dashboard-card">
                <div class="card-heading">
                    🛠️ Machine Sensor Inputs
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

        air_temp = st.slider(
            "Air Temperature (K)",
            295.0, 305.0, 300.0, 0.1
        )

        process_temp = st.slider(
            "Process Temperature (K)",
            305.0, 315.0, 310.0, 0.1
        )

        rpm = st.slider(
            "Rotational Speed (rpm)",
            1000, 3000, 1500
        )

        torque = st.slider(
            "Torque (Nm)",
            3.0, 80.0, 40.0, 0.5
        )

        tool_wear = st.slider(
            "Tool Wear (minutes)",
            0, 250, 100
        )

        run_button = st.button(
            "▶ Run Prediction",
            use_container_width=True
        )

        reset_button = st.button(
            "↻ Reset Inputs",
            use_container_width=True
        )

        if reset_button:
            st.rerun()

    # PREDICTION RESULTS

    with right:

        st.markdown(
            """
            <div class="dashboard-card">
                <div class="card-heading">
                    📊 Prediction Results
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

        if run_button:

            st.warning(
                "Sensor values received. "
                "Connect the trained SVM and VQC "
                "prediction functions to display actual results."
            )

        else:

            st.info(
                "Enter or adjust sensor values and select "
                "'Run Prediction' to begin."
            )

        # CURRENT SENSOR SUMMARY

        st.markdown(
            """
            <div class="dashboard-card">
                <div class="card-heading">
                    📋 Current Sensor Readings
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

        s1, s2 = st.columns(2)

        with s1:
            st.metric("Air Temperature", f"{air_temp} K")
            st.metric("Rotational Speed", f"{rpm} rpm")
            st.metric("Tool Wear", f"{tool_wear} min")

        with s2:
            st.metric("Process Temperature", f"{process_temp} K")
            st.metric("Torque", f"{torque} Nm")

    # --------------------------------------------------
    # MODEL COMPARISON SUMMARY
    # --------------------------------------------------

    st.markdown("---")

    st.subheader("📈 Model Performance Comparison")

    if results is not None:

        st.dataframe(
            results,
            use_container_width=True,
            hide_index=True
        )

    else:

        st.info(
            "Run train_compare.py to generate "
            "comparison_results.csv."
        )

# --------------------------------------------------
# LIVE PREDICTION PAGE
# --------------------------------------------------

elif page == "Live Prediction":

    st.title("Live Machine Prediction")

    st.write(
        "Enter the machine sensor values "
        "to compare Classical ML and Quantum ML predictions."
    )

    st.subheader("Machine Sensor Inputs")

    col1, col2 = st.columns(2)

    with col1:
        air_temp = st.slider(
            "Air temperature [K]",
            min_value=295.0,
            max_value=305.0,
            value=300.0,
            step=0.1
        )

        process_temp = st.slider(
            "Process temperature [K]",
            min_value=305.0,
            max_value=315.0,
            value=310.0,
            step=0.1
        )

        rpm = st.slider(
            "Rotational speed [rpm]",
            min_value=1000,
            max_value=3000,
            value=1500,
            step=10
        )

    with col2:
        torque = st.slider(
            "Torque [Nm]",
            min_value=3.0,
            max_value=80.0,
            value=40.0,
            step=0.5
        )

        tool_wear = st.slider(
            "Tool wear [min]",
            min_value=0,
            max_value=250,
            value=100,
            step=1
        )

    if st.button("Predict Machine Condition"):

        sensor_values = [
            air_temp,
            process_temp,
            rpm,
            torque,
            tool_wear
        ]

        try:
            prediction = predict_machine(sensor_values)

            st.subheader("Prediction Results")

            col1, col2 = st.columns(2)

            with col1:
                st.markdown("### Classical ML")

                if prediction["classical_prediction"] == 1:
                    st.error("Machine Failure Predicted")
                else:
                    st.success("No Machine Failure Predicted")

                st.metric(
                    "Failure Score",
                    f'{prediction["classical_score"] * 100:.2f}%'
                )

            with col2:
                st.markdown("### Quantum ML")

                if prediction["quantum_prediction"] == 1:
                    st.error("Machine Failure Predicted")
                else:
                    st.success("No Machine Failure Predicted")

                st.metric(
                    "Quantum Model Score",
                    f'{prediction["quantum_score"]:.4f}'
                )

            st.caption(
                "These are model predictions for the entered "
                "sensor values, not a guarantee of actual machine condition."
            )

        except Exception as e:
            st.error(f"Prediction failed: {e}")

# --------------------------------------------------
# MODEL COMPARISON PAGE
# --------------------------------------------------

elif page == "Model Comparison":

    st.title("Classical ML vs Quantum ML")

    if results is not None:

        st.subheader("Final Test Results")

        st.dataframe(
            results,
            use_container_width=True,
            hide_index=True
        )

        st.subheader("Model Performance Comparison")

        metric = st.selectbox(
            "Choose metric",
            ["Accuracy", "Precision", "Recall", "F1-score"]
        )

        if metric in results.columns:

            fig = px.bar(
                results,
                x="Model",
                y=metric,
                color="Model",
                title=f"{metric} Comparison",
                text_auto=".3f"
            )

            fig.update_layout(
                template="plotly_white",
                paper_bgcolor="#ffffff",
                plot_bgcolor="#ffffff",
                font_color="#0b1b3a"
            )

            st.plotly_chart(
                fig,
                use_container_width=True
            )

        else:

            st.warning(
                f"The column '{metric}' was not found "
                "in comparison_results.csv."
            )

    else:

        st.warning(
            "comparison_results.csv was not found. "
            "Run train_compare.py first."
        )

# --------------------------------------------------
# DATASET PAGE
# --------------------------------------------------

elif page == "Dataset":

    st.title("Dataset Information")

    st.write(
        "This section will display the training and "
        "testing dataset details."
    )

    st.info(
        "Connect the dataset CSV file to display "
        "sample records, features and dataset statistics."
    )

# --------------------------------------------------
# DOCUMENTATION PAGE
# --------------------------------------------------

elif page == "Documentation":

    st.title("Project Documentation")

    st.subheader("Quantum Predictive Maintenance")

    st.write(
        "This project compares Classical Machine Learning "
        "and Quantum Machine Learning for predictive "
        "maintenance of industrial machines."
    )

    st.markdown("""
    **Classical Model:** Support Vector Machine (SVM)

    **Quantum Model:** Variational Quantum Classifier (VQC)

    **Input Features:**
    - Air temperature
    - Process temperature
    - Rotational speed
    - Torque
    - Tool wear
    """)